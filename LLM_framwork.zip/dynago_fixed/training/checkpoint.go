package training

import (
	"dynago-ai/core"
	"dynago-ai/nn"
	"dynago-ai/transformer"
	"encoding/json"
	"fmt"
	"log"
	"os"
)

type checkpoint struct {
	Version int `json:"version"`
	Dim     int `json:"dim"`
	Layers  int `json:"layers"`
	Vocab   int `json:"vocab"`
	MaxCtx  int `json:"max_ctx"`
	Weights map[string][]float64 `json:"weights"`
}

// SaveModel writes all trainable weights to a JSON checkpoint
func SaveModel(path string, model *transformer.Transformer, embed *nn.Embedding) error {
	chk := &checkpoint{
		Version: 1,
		Dim:     model.Dim,
		Layers:  len(model.Blocks),
		Vocab:   model.Vocab,
		MaxCtx:  model.PosEmb.R,
		Weights: make(map[string][]float64),
	}

	flattenTensors(chk.Weights, "embed", embed.Params())
	flattenTensors(chk.Weights, "model", model.Params())

	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	enc.SetIndent("", "  ")
	return enc.Encode(chk)
}

// LoadModel restores a checkpoint from disk
func LoadModel(path string) (*transformer.Transformer, *nn.Embedding, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, nil, err
	}
	defer f.Close()

	chk := &checkpoint{}
	if err := json.NewDecoder(f).Decode(chk); err != nil {
		return nil, nil, err
	}

	if chk.Version != 1 {
		return nil, nil, fmt.Errorf("unsupported checkpoint version %d", chk.Version)
	}

	model := transformer.NewTransformer(chk.Dim, chk.Layers, chk.Vocab, chk.MaxCtx)
	embed := nn.NewEmbedding(chk.Vocab, chk.Dim)

	embedParams := embed.Params()
	modelParams := model.Params()

	if err := restoreTensors(chk.Weights, "embed", embedParams); err != nil {
		return nil, nil, fmt.Errorf("embed restore: %w", err)
	}
	if err := restoreTensors(chk.Weights, "model", modelParams); err != nil {
		return nil, nil, fmt.Errorf("model restore: %w", err)
	}

	return model, embed, nil
}

func flattenTensors(m map[string][]float64, prefix string, params []*core.Tensor) {
	for i, p := range params {
		key := fmt.Sprintf("%s_%d", prefix, i)
		data := make([]float64, len(p.Data))
		copy(data, p.Data)
		m[key] = data
	}
}

func restoreTensors(m map[string][]float64, prefix string, params []*core.Tensor) error {
	for i, p := range params {
		key := fmt.Sprintf("%s_%d", prefix, i)
		data, ok := m[key]
		if !ok {
			log.Printf("Warning: missing tensor key %s", key)
			continue
		}
		if len(data) != len(p.Data) {
			return fmt.Errorf("shape mismatch for %s: got %d want %d", key, len(data), len(p.Data))
		}
		copy(p.Data, data)
	}
	return nil
}