package training

import (
	"dynago-ai/core"
	"dynago-ai/loss"
	"dynago-ai/nn"
	"dynago-ai/optimizer"
	"dynago-ai/transformer"
	"fmt"
	"math/rand"
	"log"
)

// Config holds training hyperparameters
type Config struct {
	LR         float64
	WDecay     float64
	Epochs     int
	ContextLen int
	BatchLog   int
	GradClip   float64
}

func DefaultConfig() Config {
	return Config{
		LR:         3e-4,
		WDecay:     0.01,
		Epochs:     3,
		ContextLen: 64,
		BatchLog:   50,
		GradClip:   1.0,
	}
}

// Trainer ties model, embedding, and optimizer together
type Trainer struct {
	Model  *transformer.Transformer
	Embed  *nn.Embedding
	Opt    *optimizer.Adam
	Config Config
	params []*core.Tensor
}

func NewTrainer(model *transformer.Transformer, embed *nn.Embedding, cfg Config) *Trainer {
	opt := optimizer.NewAdamW(cfg.LR, cfg.WDecay)
	t := &Trainer{
		Model:  model,
		Embed:  embed,
		Opt:    opt,
		Config: cfg,
	}
	t.params = append(embed.Params(), model.Params()...)
	return t
}

// Train runs the full training loop over tokenized integer data.
// onStep is called periodically with (epoch, step, avgLoss) — can be nil.
func (t *Trainer) Train(data []int, onStep func(epoch, step int, avgLoss float64)) {
	ctx := t.Config.ContextLen

	for epoch := 0; epoch < t.Config.Epochs; epoch++ {
		epochLoss := 0.0
		steps := 0

		positions := make([]int, 0, len(data)/ctx)
		for i := 0; i+ctx+1 <= len(data); i += ctx {
			positions = append(positions, i)
		}
		rand.Shuffle(len(positions), func(a, b int) {
			positions[a], positions[b] = positions[b], positions[a]
		})

		for _, pos := range positions {
			input := data[pos : pos+ctx]
			targets := data[pos+1 : pos+ctx+1]

			// Validate input
			if len(input) != ctx || len(targets) != ctx {
				log.Printf("Warning: input/target length mismatch at position %d", pos)
				continue
			}

			t.zeroGrad()

			x := t.Embed.Forward(input)
			logits := t.Model.Forward(x)

			l, dLogits := loss.CrossEntropy(logits, targets)
			epochLoss += l

			dx := t.Model.Backward(dLogits)
			t.Embed.Backward(dx)

			optimizer.ClipGradNorm(t.params, t.Config.GradClip)
			t.Opt.Update(t.params)
			steps++

			if onStep != nil && steps%t.Config.BatchLog == 0 {
				onStep(epoch+1, steps, epochLoss/float64(steps))
			}
		}

		avgLoss := 0.0
		if steps > 0 {
			avgLoss = epochLoss / float64(steps)
		}
		fmt.Printf("[epoch %d] avg_loss=%.4f  steps=%d\n", epoch+1, avgLoss, steps)
	}
}

func (t *Trainer) zeroGrad() {
	t.Embed.ZeroGrad()
	t.Model.ZeroGrad()
}
