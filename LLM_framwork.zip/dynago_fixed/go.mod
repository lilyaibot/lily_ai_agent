module dynago-ai

go 1.21
