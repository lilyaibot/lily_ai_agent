package core

import "math"

func Add(a, b *Tensor) *Tensor {
	if a.R != b.R || a.C != b.C {
		panic("shape mismatch in Add")
	}
	out := Zeros(a.R, a.C)
	for i := range out.Data {
		out.Data[i] = a.Data[i] + b.Data[i]
	}
	return out
}

func AddInPlace(a, b *Tensor) {
	if a.R != b.R || a.C != b.C {
		panic("shape mismatch in AddInPlace")
	}
	for i := range a.Data {
		a.Data[i] += b.Data[i]
	}
}

func Scale(a *Tensor, s float64) *Tensor {
	out := Zeros(a.R, a.C)
	for i := range out.Data {
		out.Data[i] = a.Data[i] * s
	}
	return out
}

// MatMul computes a @ b, shapes [M,K] x [K,N] -> [M,N]
func MatMul(a, b *Tensor) *Tensor {
	out := Zeros(a.R, b.C)
	for i := 0; i < a.R; i++ {
		for k := 0; k < a.C; k++ {
			av := a.Data[i*a.C+k]
			if av == 0 {
				continue
			}
			for j := 0; j < b.C; j++ {
				out.Data[i*b.C+j] += av * b.Data[k*b.C+j]
			}
		}
	}
	return out
}

// SoftmaxRows applies softmax independently to each row (numerically stable)
func SoftmaxRows(x *Tensor) *Tensor {
	out := Zeros(x.R, x.C)
	for i := 0; i < x.R; i++ {
		offset := i * x.C
		max := x.Data[offset]
		for j := 1; j < x.C; j++ {
			if v := x.Data[offset+j]; v > max {
				max = v
			}
		}
		sum := 0.0
		for j := 0; j < x.C; j++ {
			e := math.Exp(x.Data[offset+j] - max)
			out.Data[offset+j] = e
			sum += e
		}
		for j := 0; j < x.C; j++ {
			out.Data[offset+j] /= sum
		}
	}
	return out
}

// SoftmaxBackward computes upstream gradient through softmax.
// s = softmax output [R,C], dout = upstream grad [R,C]
func SoftmaxBackward(s, dout *Tensor) *Tensor {
	dx := Zeros(s.R, s.C)
	for i := 0; i < s.R; i++ {
		// dot = sum(s[i] * dout[i])
		dot := 0.0
		for j := 0; j < s.C; j++ {
			dot += s.Data[i*s.C+j] * dout.Data[i*s.C+j]
		}
		for j := 0; j < s.C; j++ {
			dx.Data[i*s.C+j] = s.Data[i*s.C+j] * (dout.Data[i*s.C+j] - dot)
		}
	}
	return dx
}

// GELU activation (tanh approximation)
func GELU(x *Tensor) *Tensor {
	out := Zeros(x.R, x.C)
	for i, v := range x.Data {
		out.Data[i] = geluScalar(v)
	}
	return out
}

func geluScalar(v float64) float64 {
	return 0.5 * v * (1.0 + math.Tanh(0.7978845608*(v+0.044715*v*v*v)))
}

// GELUBackward computes upstream gradient through GELU
func GELUBackward(x, dout *Tensor) *Tensor {
	out := Zeros(x.R, x.C)
	for i, v := range x.Data {
		inner := 0.7978845608 * (v + 0.044715*v*v*v)
		t := math.Tanh(inner)
		dt := 1.0 - t*t // sech²
		grad := 0.5*(1.0+t) + 0.5*v*dt*0.7978845608*(1.0+3*0.044715*v*v)
		out.Data[i] = grad * dout.Data[i]
	}
	return out
}

// Clip gradient to prevent explosions
func ClipGrad(t *Tensor, maxNorm float64) {
	norm := 0.0
	for _, v := range t.Grad {
		norm += v * v
	}
	norm = math.Sqrt(norm)
	if norm > maxNorm {
		scale := maxNorm / norm
		for i := range t.Grad {
			t.Grad[i] *= scale
		}
	}
}