package core

import "math/rand"

// Tensor is the fundamental data structure.
// R = rows, C = cols, Data = values, Grad = accumulated gradients.
type Tensor struct {
	Data []float64
	Grad []float64
	R, C int
}

func NewTensor(r, c int) *Tensor {
	t := &Tensor{
		Data: make([]float64, r*c),
		Grad: make([]float64, r*c),
		R:    r,
		C:    c,
	}
	// Kaiming-style small random init
	scale := 0.02
	for i := range t.Data {
		t.Data[i] = rand.NormFloat64() * scale
	}
	return t
}

func Zeros(r, c int) *Tensor {
	return &Tensor{
		Data: make([]float64, r*c),
		Grad: make([]float64, r*c),
		R:    r,
		C:    c,
	}
}

func Ones(r, c int) *Tensor {
	t := Zeros(r, c)
	for i := range t.Data {
		t.Data[i] = 1.0
	}
	return t
}

func FromSlice(v []float64) *Tensor {
	t := Zeros(1, len(v))
	copy(t.Data, v)
	return t
}

func (t *Tensor) ZeroGrad() {
	for i := range t.Grad {
		t.Grad[i] = 0
	}
}

func (t *Tensor) At(r, c int) float64 {
	return t.Data[r*t.C+c]
}

func (t *Tensor) Set(r, c int, v float64) {
	t.Data[r*t.C+c] = v
}

func (t *Tensor) AddGrad(r, c int, v float64) {
	t.Grad[r*t.C+c] += v
}

func Transpose(t *Tensor) *Tensor {
	out := Zeros(t.C, t.R)
	for i := 0; i < t.R; i++ {
		for j := 0; j < t.C; j++ {
			out.Data[j*out.C+i] = t.Data[i*t.C+j]
		}
	}
	return out
}

func (t *Tensor) Clone() *Tensor {
	out := Zeros(t.R, t.C)
	copy(out.Data, t.Data)
	copy(out.Grad, t.Grad)
	return out
}