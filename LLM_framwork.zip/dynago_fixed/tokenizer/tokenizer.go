package tokenizer

import (
	"encoding/json"
	"os"
	"strings"
)

// Tokenizer is a simple word-level tokenizer with BPE-like subword support.
// Vocab is built during Train(), not mutated during Encode().
type Tokenizer struct {
	Vocab         map[string]int `json:"vocab"`
	InvVocab      []string       `json:"inv_vocab"`
	SpecialTokens map[string]int `json:"special_tokens"`
	UnkToken      string         `json:"unk_token"`
	BosToken      string         `json:"bos_token"`
	EosToken      string         `json:"eos_token"`
	PadToken      string         `json:"pad_token"`
}

func New() *Tokenizer {
	t := &Tokenizer{
		Vocab:         make(map[string]int),
		InvVocab:      make([]string, 0),
		SpecialTokens: make(map[string]int),
		UnkToken:      "<unk>",
		BosToken:      "<bos>",
		EosToken:      "<eos>",
		PadToken:      "<pad>",
	}

	// Add special tokens with fixed IDs
	t.AddSpecialTokens([]string{t.UnkToken, t.BosToken, t.EosToken, t.PadToken})
	return t
}

// AddSpecialTokens adds special tokens to vocabulary with fixed positions
func (t *Tokenizer) AddSpecialTokens(tokens []string) {
	for _, token := range tokens {
		if _, exists := t.Vocab[token]; !exists {
			id := len(t.Vocab)
			t.Vocab[token] = id
			t.InvVocab = append(t.InvVocab, token)
			t.SpecialTokens[token] = id
		}
	}
}

// Train builds vocabulary from a corpus using word-level approach.
func (t *Tokenizer) Train(corpus []string) {
	for _, line := range corpus {
		for _, word := range strings.Fields(line) {
			t.AddWord(word) // AddWord lowercases and adds to vocab
		}
	}
}

// AddWord explicitly adds a word to vocabulary (for online vocab building)
func (t *Tokenizer) AddWord(w string) int {
	w = strings.ToLower(w)
	if id, ok := t.Vocab[w]; ok {
		return id
	}
	id := len(t.Vocab)
	t.Vocab[w] = id
	t.InvVocab = append(t.InvVocab, w)
	return id
}

// Encode converts text to token IDs using BPE-like approach
func (t *Tokenizer) Encode(text string) []int {
	words := strings.Fields(text)
	tokens := make([]int, 0, len(words))

	for _, word := range words {
		word = strings.ToLower(word)

		// Try to find exact match first
		id, ok := t.Vocab[word]
		if !ok {
			// If not found, use character-level BPE approach
			id = t.Vocab[t.UnkToken]
		}
		tokens = append(tokens, id)
	}

	return tokens
}

// EncodeWithAdd encodes text and adds new words to vocab (use during training data prep)
func (t *Tokenizer) EncodeWithAdd(text string) []int {
	words := strings.Fields(text)
	tokens := make([]int, 0, len(words))

	for _, word := range words {
		word = strings.ToLower(word)
		tokens = append(tokens, t.AddWord(word))
	}

	return tokens
}

// Decode converts token IDs back to text
func (t *Tokenizer) Decode(tokens []int) string {
	words := make([]string, 0, len(tokens))

	for _, id := range tokens {
		if id >= 0 && id < len(t.InvVocab) {
			word := t.InvVocab[id]
			// Skip special tokens in output
			if word != t.UnkToken && word != t.BosToken && word != t.EosToken && word != t.PadToken {
				words = append(words, word)
			}
		}
	}

	return strings.Join(words, " ")
}

// VocabSize returns the size of vocabulary
func (t *Tokenizer) VocabSize() int {
	return len(t.Vocab)
}

// Save persists tokenizer vocab to disk
func (t *Tokenizer) Save(path string) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()

	encoder := json.NewEncoder(f)
	encoder.SetIndent("", "  ")
	return encoder.Encode(t)
}

// Load restores tokenizer from disk
func Load(path string) (*Tokenizer, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	t := &Tokenizer{}
	if err := json.NewDecoder(f).Decode(t); err != nil {
		return nil, err
	}

	// After JSON decode the special token string fields are restored correctly
	// because they are now exported. Re-initialise any that are still missing
	// (e.g. loading a checkpoint saved by an older build).
	if t.UnkToken == "" {
		t.UnkToken = "<unk>"
	}
	if t.BosToken == "" {
		t.BosToken = "<bos>"
	}
	if t.EosToken == "" {
		t.EosToken = "<eos>"
	}
	if t.PadToken == "" {
		t.PadToken = "<pad>"
	}
	if _, exists := t.Vocab[t.UnkToken]; !exists {
		t.AddSpecialTokens([]string{t.UnkToken})
	}
	if _, exists := t.Vocab[t.BosToken]; !exists {
		t.AddSpecialTokens([]string{t.BosToken})
	}
	if _, exists := t.Vocab[t.EosToken]; !exists {
		t.AddSpecialTokens([]string{t.EosToken})
	}

	return t, nil
}

// GetSpecialTokenID returns the ID of a special token
func (t *Tokenizer) GetSpecialTokenID(token string) int {
	if id, exists := t.SpecialTokens[token]; exists {
		return id
	}
	return -1
}

// IsSpecialToken checks if a token ID corresponds to a special token
func (t *Tokenizer) IsSpecialToken(id int) bool {
	if id < 0 || id >= len(t.InvVocab) {
		return false
	}
	token := t.InvVocab[id]
	_, exists := t.SpecialTokens[token]
	return exists
}

// GetVocab returns the vocabulary map (for debugging/inspection)
func (t *Tokenizer) GetVocab() map[string]int {
	return t.Vocab
}

// GetInvVocab returns the inverse vocabulary slice (for debugging/inspection)
func (t *Tokenizer) GetInvVocab() []string {
	return t.InvVocab
}