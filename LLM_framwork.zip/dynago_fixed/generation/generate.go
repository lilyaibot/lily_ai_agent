package generation

import (
	"dynago-ai/nn"
	"dynago-ai/tokenizer"
	"dynago-ai/transformer"
	"fmt"
	"math"
	"math/rand"
	"sort"
	"time"
)

// Options controls generation behavior
type Options struct {
	MaxNew     int     // max new tokens to generate
	Temp       float64 // temperature (1.0 = no change, <1 = sharper)
	TopK       int     // top-k sampling (0 = greedy)
	TopP       float64 // nucleus sampling threshold (0 = off)
	ContextLen int     // max context window
}

func DefaultOptions() Options {
	return Options{
		MaxNew:     100,
		Temp:       0.8,
		TopK:       40,
		TopP:       0.9,
		ContextLen: 128,
	}
}

// Generate produces text from a prompt
func Generate(
	model *transformer.Transformer,
	embed *nn.Embedding,
	tok *tokenizer.Tokenizer,
	prompt string,
	opts Options,
) string {
	// Input validation
	if model == nil {
		panic("model cannot be nil")
	}
	if embed == nil {
		panic("embed cannot be nil")
	}
	if tok == nil {
		panic("tokenizer cannot be nil")
	}

	tokens := tok.Encode(prompt)
	if len(tokens) == 0 {
		tokens = []int{1} // <bos>
	}

	for i := 0; i < opts.MaxNew; i++ {
		// Truncate to context window
		ctx := tokens
		if len(ctx) > opts.ContextLen {
			ctx = ctx[len(ctx)-opts.ContextLen:]
		}

		// Forward pass
		x := embed.Forward(ctx)
		logits := model.Forward(x) // [seq, vocab]

		// Take logits for last token
		lastRow := logits.R - 1
		rawLogits := logits.Data[lastRow*logits.C : (lastRow+1)*logits.C]

		next := sample(rawLogits, opts)
		tokens = append(tokens, next)

		// Stop at EOS
		if next == 2 { // <eos>
			break
		}
	}

	return tok.Decode(tokens)
}

// GenerateWithLogging produces text from a prompt with logging
func GenerateWithLogging(
	model *transformer.Transformer,
	embed *nn.Embedding,
	tok *tokenizer.Tokenizer,
	prompt string,
	opts Options,
) string {
	// Input validation
	if model == nil {
		panic("model cannot be nil")
	}
	if embed == nil {
		panic("embed cannot be nil")
	}
	if tok == nil {
		panic("tokenizer cannot be nil")
	}

	fmt.Printf("[INFO] Starting generation with prompt: %s\n", prompt)
	startTime := time.Now()

	tokens := tok.Encode(prompt)
	if len(tokens) == 0 {
		tokens = []int{1} // <bos>
	}
	fmt.Printf("[INFO] Initial tokens: %v\n", tokens)

	for i := 0; i < opts.MaxNew; i++ {
		// Truncate to context window
		ctx := tokens
		if len(ctx) > opts.ContextLen {
			ctx = ctx[len(ctx)-opts.ContextLen:]
		}

		// Forward pass
		x := embed.Forward(ctx)
		logits := model.Forward(x) // [seq, vocab]

		// Take logits for last token
		lastRow := logits.R - 1
		rawLogits := logits.Data[lastRow*logits.C : (lastRow+1)*logits.C]

		next := sample(rawLogits, opts)
		tokens = append(tokens, next)

		// Log progress
		if i%10 == 0 {
			fmt.Printf("[INFO] Generated token %d: %d\n", i, next)
		}

		// Stop at EOS
		if next == 2 { // <eos>
			fmt.Printf("[INFO] EOS token encountered at step %d\n", i)
			break
		}
	}

	duration := time.Since(startTime)
	fmt.Printf("[INFO] Generation completed in %v\n", duration)
	return tok.Decode(tokens)
}

// BeamSearch generates text using beam search strategy
func BeamSearch(
	model *transformer.Transformer,
	embed *nn.Embedding,
	tok *tokenizer.Tokenizer,
	prompt string,
	opts Options,
	beamSize int,
) string {
	// Input validation
	if model == nil {
		panic("model cannot be nil")
	}
	if embed == nil {
		panic("embed cannot be nil")
	}
	if tok == nil {
		panic("tokenizer cannot be nil")
	}

	tokens := tok.Encode(prompt)
	if len(tokens) == 0 {
		tokens = []int{1} // <bos>
	}

	// Simple beam search implementation
	type beamItem struct {
		tokens []int
		score  float64 // log probability (so higher is better)
	}
	beam := []beamItem{{
		tokens: tokens,
		score:  0.0,
	}}

	// Helper for softmax and log softmax
	softmaxWithTemp := func(logits []float64, temp float64) []float64 {
		if temp <= 0 {
			temp = 1.0
		}
		scaled := make([]float64, len(logits))
		for i, v := range logits {
			scaled[i] = v / temp
		}
		return softmax(scaled)
	}

	for i := 0; i < opts.MaxNew; i++ {
		var candidates []beamItem

		for _, item := range beam {
			ctx := item.tokens
			if len(ctx) > opts.ContextLen {
				ctx = ctx[len(ctx)-opts.ContextLen:]
			}

			x := embed.Forward(ctx)
			logits := model.Forward(x)

			lastRow := logits.R - 1
			rawLogits := logits.Data[lastRow*logits.C : (lastRow+1)*logits.C]

			// Convert to probabilities (with temperature)
			probs := softmaxWithTemp(rawLogits, opts.Temp)

			// Apply top-k filtering if desired
			if opts.TopK > 0 && opts.TopK < len(probs) {
				// Find top-k indices
				type ip struct{ i int; p float64 }
				pairs := make([]ip, len(probs))
				for j, p := range probs {
					pairs[j] = ip{j, p}
				}
				sort.Slice(pairs, func(a, b int) bool { return pairs[a].p > pairs[b].p })

				filtered := make([]float64, len(probs))
				for j := 0; j < opts.TopK && j < len(pairs); j++ {
					filtered[pairs[j].i] = pairs[j].p
				}
				probs = filtered
			}

			// Renormalize
			sum := 0.0
			for _, p := range probs {
				sum += p
			}
			if sum > 0 {
				for j := range probs {
					probs[j] /= sum
				}
			}

			// Convert to log probabilities (with epsilon)
			logProbs := make([]float64, len(probs))
			for j, p := range probs {
				if p > 0 {
					logProbs[j] = math.Log(p)
				} else {
					logProbs[j] = -1e30 // very low log prob
				}
			}

			// Consider all tokens (or top-k to reduce candidates)
			topK := opts.TopK
			if topK <= 0 {
				topK = len(logProbs)
			}
			type ip2 struct{ i int; lp float64 }
			pairs := make([]ip2, len(logProbs))
			for j, lp := range logProbs {
				pairs[j] = ip2{j, lp}
			}
			sort.Slice(pairs, func(a, b int) bool { return pairs[a].lp > pairs[b].lp })

			for j := 0; j < topK && j < len(pairs); j++ {
				newTokens := make([]int, len(item.tokens)+1)
				copy(newTokens, item.tokens)
				newTokens[len(item.tokens)] = pairs[j].i
				newScore := item.score + pairs[j].lp // sum log probs
				candidates = append(candidates, beamItem{tokens: newTokens, score: newScore})
			}
		}

		// Keep top beamSize candidates
		sort.Slice(candidates, func(a, b int) bool { return candidates[a].score > candidates[b].score })
		if len(candidates) > beamSize {
			candidates = candidates[:beamSize]
		}

		beam = candidates

		// Check for EOS in any candidate
		for _, item := range beam {
			if len(item.tokens) > 0 && item.tokens[len(item.tokens)-1] == 2 { // <eos>
				return tok.Decode(item.tokens)
			}
		}
	}

	// Return best beam result
	best := beam[0]
	return tok.Decode(best.tokens)
}

// sample picks the next token from logits using the chosen strategy
func sample(logits []float64, opts Options) int {
	vocab := len(logits)

	// Apply temperature
	temp := opts.Temp
	if temp <= 0 {
		temp = 1.0
	}
	scaled := make([]float64, vocab)
	for i, v := range logits {
		scaled[i] = v / temp
	}

	// Greedy if no sampling
	if opts.TopK == 0 && opts.TopP == 0 {
		return argmax(scaled)
	}

	// Convert to probabilities
	probs := softmax(scaled)

	// Top-K filtering
	if opts.TopK > 0 && opts.TopK < vocab {
		type ip struct{ i int; p float64 }
		pairs := make([]ip, vocab)
		for i, p := range probs {
			pairs[i] = ip{i, p}
		}
		sort.Slice(pairs, func(a, b int) bool { return pairs[a].p > pairs[b].p })

		filtered := make([]float64, vocab)
		for j := 0; j < opts.TopK && j < len(pairs); j++ {
			filtered[pairs[j].i] = pairs[j].p
		}
		probs = filtered
	}

	// Top-P (nucleus) filtering
	if opts.TopP > 0 {
		type ip struct{ i int; p float64 }
		pairs := make([]ip, 0, vocab)
		for i, p := range probs {
			if p > 0 {
				pairs = append(pairs, ip{i, p})
			}
		}
		sort.Slice(pairs, func(a, b int) bool { return pairs[a].p > pairs[b].p })

		cumulative := 0.0
		filtered := make([]float64, vocab)
		for _, pair := range pairs {
			filtered[pair.i] = pair.p
			cumulative += pair.p
			if cumulative >= opts.TopP {
				break
			}
		}
		probs = filtered
	}

	// Renormalize probabilities
	sum := 0.0
	for _, p := range probs {
		sum += p
	}
	if sum == 0 {
		return argmax(logits)
	}
	for i := range probs {
		probs[i] /= sum
	}

	// Multinomial sample
	r := rand.Float64()
	cumulative := 0.0
	for i, p := range probs {
		cumulative += p
		if r <= cumulative {
			return i
		}
	}
	return len(probs) - 1
}

func argmax(v []float64) int {
	best, idx := v[0], 0
	for i, x := range v[1:] {
		if x > best {
			best, idx = x, i+1
		}
	}
	return idx
}

func softmax(v []float64) []float64 {
	max := v[0]
	for _, x := range v[1:] {
		if x > max {
			max = x
		}
	}
	out := make([]float64, len(v))
	sum := 0.0
	for i, x := range v {
		e := math.Exp(x - max)
		out[i] = e
		sum += e
	}
	for i := range out {
		out[i] /= sum
	}
	return out
}