package optimizer

import (
	"dynago-ai/core"
	"math"
)

// Adam optimizer with β1=0.9, β2=0.999, ε=1e-8
type Adam struct {
	LR     float64
	Beta1  float64
	Beta2  float64
	Eps    float64
	WDecay float64 // weight decay (decoupled, applied after update)
	Step   int
	// per-param moment estimates (indexed by param pointer address)
	m map[*core.Tensor][]float64 // first moment
	v map[*core.Tensor][]float64 // second moment
}

func NewAdam(lr float64) *Adam {
	return &Adam{
		LR:    lr,
		Beta1: 0.9,
		Beta2: 0.999,
		Eps:   1e-8,
		m:     make(map[*core.Tensor][]float64),
		v:     make(map[*core.Tensor][]float64),
	}
}

func NewAdamW(lr, wdecay float64) *Adam {
	a := NewAdam(lr)
	a.WDecay = wdecay
	return a
}

// Update applies one Adam step to all parameters.
// Moment buffers are lazily allocated on first encounter of each param pointer.
func (a *Adam) Update(params []*core.Tensor) {
	a.Step++
	// Bias-corrected learning rate (computed once per step)
	bc1 := 1.0 - math.Pow(a.Beta1, float64(a.Step))
	bc2 := 1.0 - math.Pow(a.Beta2, float64(a.Step))
	lrt := a.LR * math.Sqrt(bc2) / bc1

	for _, p := range params {
		if _, ok := a.m[p]; !ok {
			a.m[p] = make([]float64, len(p.Data))
			a.v[p] = make([]float64, len(p.Data))
		}
		m := a.m[p]
		v := a.v[p]
		for i, g := range p.Grad {
			// Update biased first and second moment estimates
			m[i] = a.Beta1*m[i] + (1-a.Beta1)*g
			v[i] = a.Beta2*v[i] + (1-a.Beta2)*g*g

			// Bias-corrected update
			step := lrt * m[i] / (math.Sqrt(v[i]) + a.Eps)
			p.Data[i] -= step

			// Decoupled weight decay (AdamW)
			if a.WDecay != 0 {
				p.Data[i] -= a.LR * a.WDecay * p.Data[i]
			}
		}
	}
}

// ClipGradNorm rescales all gradients so the global L2 norm does not exceed
// maxNorm. This is the standard per-step gradient clipping used before Update.
func ClipGradNorm(params []*core.Tensor, maxNorm float64) {
	if maxNorm <= 0 {
		return
	}
	norm := 0.0
	for _, p := range params {
		for _, g := range p.Grad {
			norm += g * g
		}
	}
	norm = math.Sqrt(norm)
	if norm > maxNorm {
		scale := maxNorm / norm
		for _, p := range params {
			for i := range p.Grad {
				p.Grad[i] *= scale
			}
		}
	}
}