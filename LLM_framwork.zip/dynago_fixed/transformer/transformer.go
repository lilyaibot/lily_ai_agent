package transformer

import (
	"dynago-ai/core"
	"dynago-ai/nn"
	"math"
)

type Transformer struct {
	Blocks []*Block
	LnF    *nn.LayerNorm
	LMHead *nn.Linear
	PosEmb *core.Tensor
	Dim    int
	Vocab  int
}

func NewTransformer(dim, layers, vocab, maxCtx int) *Transformer {
	blocks := make([]*Block, layers)
	for i := range blocks {
		blocks[i] = NewBlock(dim)
	}

	posEmb := core.Zeros(maxCtx, dim)
	for pos := 0; pos < maxCtx; pos++ {
		for i := 0; i < dim; i += 2 {
			angle := float64(pos) / math.Pow(10000, float64(i)/float64(dim))
			posEmb.Data[pos*dim+i] = math.Sin(angle)
			if i+1 < dim {
				posEmb.Data[pos*dim+i+1] = math.Cos(angle)
			}
		}
	}

	return &Transformer{
		Blocks: blocks,
		LnF:    nn.NewLayerNorm(dim),
		LMHead: nn.NewLinear(dim, vocab),
		PosEmb: posEmb,
		Dim:    dim,
		Vocab:  vocab,
	}
}

func (t *Transformer) Forward(x *core.Tensor) *core.Tensor {
	// Add positional embeddings directly (x is already a fresh tensor from embed)
	seq := x.R
	for i := 0; i < seq && i < t.PosEmb.R; i++ {
		for d := 0; d < t.Dim; d++ {
			x.Data[i*t.Dim+d] += t.PosEmb.Data[i*t.Dim+d]
		}
	}

	for _, b := range t.Blocks {
		x = b.Forward(x)
	}

	x = t.LnF.Forward(x)
	return t.LMHead.Forward(x)
}

func (t *Transformer) Backward(dLogits *core.Tensor) *core.Tensor {
	dx := t.LMHead.Backward(dLogits)
	dx = t.LnF.Backward(dx)

	for i := len(t.Blocks) - 1; i >= 0; i-- {
		dx = t.Blocks[i].Backward(dx)
	}
	return dx
}

func (t *Transformer) Params() []*core.Tensor {
	var p []*core.Tensor
	for _, b := range t.Blocks {
		p = append(p, b.Params()...)
	}
	p = append(p, t.LnF.Params()...)
	p = append(p, t.LMHead.Params()...)
	return p
}

func (t *Transformer) ZeroGrad() {
	for _, b := range t.Blocks {
		b.ZeroGrad()
	}
	t.LnF.ZeroGrad()
	t.LMHead.ZeroGrad()
}

func (t *Transformer) AddBlock() {
	t.Blocks = append(t.Blocks, NewBlock(t.Dim))
}