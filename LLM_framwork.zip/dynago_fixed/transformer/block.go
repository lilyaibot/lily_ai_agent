package transformer

import (
	"dynago-ai/core"
	"dynago-ai/nn"
)

type Block struct {
	Attn *Attention
	Ln1  *nn.LayerNorm
	Ln2  *nn.LayerNorm
	Ff1  *nn.Linear
	Ff2  *nn.Linear
	Dim  int

	ff1Out *core.Tensor
}

func NewBlock(dim int) *Block {
	return &Block{
		Attn: NewAttention(dim),
		Ln1:  nn.NewLayerNorm(dim),
		Ln2:  nn.NewLayerNorm(dim),
		Ff1:  nn.NewLinear(dim, dim*4),
		Ff2:  nn.NewLinear(dim*4, dim),
		Dim:  dim,
	}
}

func (b *Block) Forward(x *core.Tensor) *core.Tensor {
	attnOut := b.Attn.Forward(b.Ln1.Forward(x))
	h := core.Add(x, attnOut)

	ff1Out := b.Ff1.Forward(b.Ln2.Forward(h))
	b.ff1Out = ff1Out
	ff2Out := b.Ff2.Forward(core.GELU(ff1Out))
	return core.Add(h, ff2Out)
}

func (b *Block) Backward(dout *core.Tensor) *core.Tensor {
	dFF := dout.Clone()
	dH := dout.Clone()

	dFf1Act := b.Ff2.Backward(dFF)
	dFf1Out := core.GELUBackward(b.ff1Out, dFf1Act)
	dLn2Out := b.Ff1.Backward(dFf1Out)
	dHfromFF := b.Ln2.Backward(dLn2Out)
	core.AddInPlace(dH, dHfromFF)

	dx := dH.Clone()
	dLn1Out := b.Attn.Backward(dH)
	dXfromAttn := b.Ln1.Backward(dLn1Out)
	core.AddInPlace(dx, dXfromAttn)
	return dx
}

func (b *Block) Params() []*core.Tensor {
	p := b.Attn.Params()
	for _, l := range []*nn.LayerNorm{b.Ln1, b.Ln2} {
		p = append(p, l.Params()...)
	}
	for _, l := range []*nn.Linear{b.Ff1, b.Ff2} {
		p = append(p, l.Params()...)
	}
	return p
}

func (b *Block) ZeroGrad() {
	b.Attn.ZeroGrad()
	b.Ln1.ZeroGrad()
	b.Ln2.ZeroGrad()
	b.Ff1.ZeroGrad()
	b.Ff2.ZeroGrad()
}
