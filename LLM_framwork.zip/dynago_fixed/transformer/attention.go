package transformer

import (
	"dynago-ai/core"
	"dynago-ai/nn"
	"math"
)

type Attention struct {
	Wq, Wk, Wv, Wo *nn.Linear
	Dim             int

	lastX       *core.Tensor
	lastQ       *core.Tensor
	lastK       *core.Tensor
	lastV       *core.Tensor
	lastWeights *core.Tensor
	lastAttn    *core.Tensor
}

func NewAttention(dim int) *Attention {
	return &Attention{
		Wq:  nn.NewLinear(dim, dim),
		Wk:  nn.NewLinear(dim, dim),
		Wv:  nn.NewLinear(dim, dim),
		Wo:  nn.NewLinear(dim, dim),
		Dim: dim,
	}
}

func (a *Attention) Forward(x *core.Tensor) *core.Tensor {
	a.lastX = x
	seq := x.R
	scale := 1.0 / math.Sqrt(float64(a.Dim))

	q := a.Wq.Forward(x)
	k := a.Wk.Forward(x)
	v := a.Wv.Forward(x)
	a.lastQ, a.lastK, a.lastV = q, k, v

	kT := core.Transpose(k)
	scores := core.MatMul(q, kT)
	scores = core.Scale(scores, scale)

	for i := 0; i < seq; i++ {
		for j := i + 1; j < seq; j++ {
			scores.Data[i*seq+j] = -1e9
		}
	}

	weights := core.SoftmaxRows(scores)
	a.lastWeights = weights

	attn := core.MatMul(weights, v)
	a.lastAttn = attn

	return a.Wo.Forward(attn)
}

func (a *Attention) Backward(dout *core.Tensor) *core.Tensor {
	scale := 1.0 / math.Sqrt(float64(a.Dim))

	dAttn := a.Wo.Backward(dout)

	dV := core.MatMul(core.Transpose(a.lastWeights), dAttn)
	dWeights := core.MatMul(dAttn, core.Transpose(a.lastV))

	dScores := core.SoftmaxBackward(a.lastWeights, dWeights)
	dScores = core.Scale(dScores, scale)

	dQ := core.MatMul(dScores, a.lastK)
	dK := core.MatMul(core.Transpose(dScores), a.lastQ)

	dxQ := a.Wq.Backward(dQ)
	dxK := a.Wk.Backward(dK)
	dxV := a.Wv.Backward(dV)

	dx := core.Add(dxQ, dxK)
	core.AddInPlace(dx, dxV)
	return dx
}

func (a *Attention) Params() []*core.Tensor {
	p := []*core.Tensor{}
	for _, l := range []*nn.Linear{a.Wq, a.Wk, a.Wv, a.Wo} {
		p = append(p, l.Params()...)
	}
	return p
}

func (a *Attention) ZeroGrad() {
	a.Wq.ZeroGrad()
	a.Wk.ZeroGrad()
	a.Wv.ZeroGrad()
	a.Wo.ZeroGrad()
}
