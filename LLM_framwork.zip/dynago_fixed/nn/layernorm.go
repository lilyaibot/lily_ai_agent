package nn

import (
	"dynago-ai/core"
	"math"
)

// LayerNorm normalizes each row then applies learned scale+shift.
type LayerNorm struct {
	Gamma, Beta *core.Tensor
	Eps         float64
	// backward cache
	lastX    *core.Tensor
	lastNorm *core.Tensor // normalized values before gamma/beta
	lastStd  []float64   // per-row std dev
}

func NewLayerNorm(dim int) *LayerNorm {
	ln := &LayerNorm{
		Gamma: core.Ones(1, dim),
		Beta:  core.Zeros(1, dim),
		Eps:   1e-5,
	}
	return ln
}

func (ln *LayerNorm) Forward(x *core.Tensor) *core.Tensor {
	ln.lastX = x
	out := core.Zeros(x.R, x.C)
	ln.lastNorm = core.Zeros(x.R, x.C)
	ln.lastStd = make([]float64, x.R)

	for r := 0; r < x.R; r++ {
		// compute mean
		mean := 0.0
		for c := 0; c < x.C; c++ {
			mean += x.Data[r*x.C+c]
		}
		mean /= float64(x.C)

		// compute variance
		variance := 0.0
		for c := 0; c < x.C; c++ {
			d := x.Data[r*x.C+c] - mean
			variance += d * d
		}
		variance /= float64(x.C)
		std := math.Sqrt(variance + ln.Eps)
		ln.lastStd[r] = std

		for c := 0; c < x.C; c++ {
			norm := (x.Data[r*x.C+c] - mean) / std
			ln.lastNorm.Data[r*x.C+c] = norm
			out.Data[r*out.C+c] = norm*ln.Gamma.Data[c] + ln.Beta.Data[c]
		}
	}
	return out
}

// Backward computes dx and accumulates dGamma, dBeta
func (ln *LayerNorm) Backward(dout *core.Tensor) *core.Tensor {
	dx := core.Zeros(dout.R, dout.C)
	N := float64(dout.C)

	for r := 0; r < dout.R; r++ {
		std := ln.lastStd[r]

		// accumulate gamma/beta grads
		for c := 0; c < dout.C; c++ {
			ln.Gamma.Grad[c] += dout.Data[r*dout.C+c] * ln.lastNorm.Data[r*dout.C+c]
			ln.Beta.Grad[c] += dout.Data[r*dout.C+c]
		}

		// d_norm[c] = dout[r,c] * gamma[c]
		dNorm := make([]float64, dout.C)
		for c := 0; c < dout.C; c++ {
			dNorm[c] = dout.Data[r*dout.C+c] * ln.Gamma.Data[c]
		}

		// sum(dNorm) and sum(dNorm * norm)
		sumDN, sumDNN := 0.0, 0.0
		for c := 0; c < dout.C; c++ {
			sumDN += dNorm[c]
			sumDNN += dNorm[c] * ln.lastNorm.Data[r*dout.C+c]
		}

		for c := 0; c < dout.C; c++ {
			norm := ln.lastNorm.Data[r*dout.C+c]
			dx.Data[r*dx.C+c] = (dNorm[c] - sumDN/N - norm*sumDNN/N) / std
		}
	}
	return dx
}

func (ln *LayerNorm) Params() []*core.Tensor { return []*core.Tensor{ln.Gamma, ln.Beta} }

func (ln *LayerNorm) ZeroGrad() {
	ln.Gamma.ZeroGrad()
	ln.Beta.ZeroGrad()
}
