package nn

import "dynago-ai/core"

// Embedding maps token IDs to dense vectors.
// Returns a [seq_len x dim] tensor — each row is one token's embedding.
type Embedding struct {
	Table    *core.Tensor // [vocab, dim]
	Dim      int
	lastToks []int // cached for backward
}

func NewEmbedding(vocab, dim int) *Embedding {
	return &Embedding{
		Table: core.NewTensor(vocab, dim),
		Dim:   dim,
	}
}

// Forward: [seq_len] int -> [seq_len, dim] Tensor
func (e *Embedding) Forward(tokens []int) *core.Tensor {
	e.lastToks = tokens
	out := core.Zeros(len(tokens), e.Dim)
	for i, tok := range tokens {
		if tok >= 0 && tok < e.Table.R { // bounds check
			for d := 0; d < e.Dim; d++ {
				out.Data[i*e.Dim+d] = e.Table.Data[tok*e.Dim+d]
			}
		}
	}
	return out
}

// Backward scatters dout gradients back into the embedding table
func (e *Embedding) Backward(dout *core.Tensor) {
	for i, tok := range e.lastToks {
		if tok >= 0 && tok < e.Table.R { // bounds check
			for d := 0; d < e.Dim; d++ {
				e.Table.Grad[tok*e.Dim+d] += dout.Data[i*e.Dim+d]
			}
		}
	}
}

func (e *Embedding) Params() []*core.Tensor { return []*core.Tensor{e.Table} }

func (e *Embedding) ZeroGrad() { e.Table.ZeroGrad() }
