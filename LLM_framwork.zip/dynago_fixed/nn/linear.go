package nn

import "dynago-ai/core"

// Linear is a fully-connected layer: y = x @ W + b
type Linear struct {
	W, B  *core.Tensor
	lastX *core.Tensor // cached for backward
}

func NewLinear(in, out int) *Linear {
	return &Linear{
		W: core.NewTensor(in, out),
		B: core.Zeros(1, out),
	}
}

func (l *Linear) Forward(x *core.Tensor) *core.Tensor {
	l.lastX = x
	y := core.MatMul(x, l.W)
	// broadcast bias addition
	for i := 0; i < y.R; i++ {
		for j := 0; j < y.C; j++ {
			y.Data[i*y.C+j] += l.B.Data[j]
		}
	}
	return y
}

// Backward accumulates gradients into W and B, returns dx
func (l *Linear) Backward(dout *core.Tensor) *core.Tensor {
	// dW = xᵀ @ dout  [in, out]
	dW := core.MatMul(core.Transpose(l.lastX), dout)
	for i := range l.W.Grad {
		l.W.Grad[i] += dW.Data[i]
	}
	// db = sum(dout, axis=0)  [1, out]
	for i := 0; i < dout.R; i++ {
		for j := 0; j < dout.C; j++ {
			l.B.Grad[j] += dout.Data[i*dout.C+j]
		}
	}
	// dx = dout @ Wᵀ  [seq, in]
	return core.MatMul(dout, core.Transpose(l.W))
}

func (l *Linear) Params() []*core.Tensor { return []*core.Tensor{l.W, l.B} }

func (l *Linear) ZeroGrad() {
	l.W.ZeroGrad()
	l.B.ZeroGrad()
}
