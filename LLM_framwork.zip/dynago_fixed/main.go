package main

import (
	"bufio"
	"flag"
	"fmt"
	"math/rand"
	"os"
	"strings"
	"time"

	"dynago-ai/generation"
	"dynago-ai/nn"
	"dynago-ai/server"
	"dynago-ai/tokenizer"
	"dynago-ai/training"
	"dynago-ai/transformer"
)

const banner = `
  ██████╗ ██╗   ██╗███╗   ██╗ █████╗  ██████╗  ██████╗        █████╗ ██╗
  ██╔══██╗╚██╗ ██╔╝████╗  ██║██╔══██╗██╔════╝ ██╔═══██╗      ██╔══██╗██║
  ██║  ██║ ╚████╔╝ ██╔██╗ ██║███████║██║  ███╗██║   ██║█████╗███████║██║
  ██║  ██║  ╚██╔╝  ██║╚██╗██║██╔══██║██║   ██║██║   ██║╚════╝██╔══██║██║
  ██████╔╝   ██║   ██║ ╚████║██║  ██║╚██████╔╝╚██████╔╝      ██║  ██║██║
  ╚═════╝    ╚═╝   ╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝  ╚═════╝       ╚═╝  ╚═╝╚═╝
  Pure-Go Transformer Engine  //  v0.1.0
`

func main() {
	// Seed random number generator
	rand.Seed(time.Now().UnixNano())

	fmt.Print(banner)

	if len(os.Args) < 2 {
		printHelp()
		os.Exit(1)
	}

	switch os.Args[1] {
	case "train":
		cmdTrain(os.Args[2:])
	case "generate", "gen":
		cmdGenerate(os.Args[2:])
	case "serve":
		cmdServe(os.Args[2:])
	case "chat":
		cmdChat(os.Args[2:])
	case "help", "--help", "-h":
		printHelp()
	default:
		fmt.Fprintf(os.Stderr, "unknown command: %s\n", os.Args[1])
		printHelp()
		os.Exit(1)
	}
}

// ─── train ───────────────────────────────────────────────────────────────────

func cmdTrain(args []string) {
	fs := flag.NewFlagSet("train", flag.ExitOnError)
	dataPath := fs.String("data", "", "path to training text file (required)")
	savePath := fs.String("save", "model.json", "checkpoint output path")
	tokPath := fs.String("tok", "tokenizer.json", "tokenizer save path")
	dim := fs.Int("dim", 128, "model dimension")
	layers := fs.Int("layers", 4, "number of transformer layers")
	ctx := fs.Int("ctx", 64, "context window length")
	epochs := fs.Int("epochs", 5, "training epochs")
	lr := fs.Float64("lr", 3e-4, "learning rate")

	if err := fs.Parse(args); err != nil {
		fatalf("parse flags: %v", err)
	}

	if *dataPath == "" {
		fmt.Fprintln(os.Stderr, "error: --data is required")
		fs.Usage()
		os.Exit(1)
	}

	// Load training data
	fmt.Printf(":: loading data from %s\n", *dataPath)
	raw, err := os.ReadFile(*dataPath)
	if err != nil {
		fatalf("cannot read data: %v", err)
	}
	lines := strings.Split(string(raw), "\n")

	// Build tokenizer
	fmt.Println(":: building vocabulary...")
	tok := tokenizer.New()
	tok.Train(lines)
	fmt.Printf("   vocab size: %d tokens\n", tok.VocabSize())

	// Tokenize all data
	var allTokens []int
	for _, line := range lines {
		allTokens = append(allTokens, tok.EncodeWithAdd(line)...)
	}
	fmt.Printf("   total tokens: %d\n", len(allTokens))

	if len(allTokens) < *ctx+2 {
		fatalf("not enough data to train with context=%d", *ctx)
	}

	// Build model
	vocab := tok.VocabSize()
	fmt.Printf(":: building model  dim=%d  layers=%d  vocab=%d  ctx=%d\n",
		*dim, *layers, vocab, *ctx)

	model := transformer.NewTransformer(*dim, *layers, vocab, *ctx*2)
	embed := nn.NewEmbedding(vocab, *dim)

	cfg := training.DefaultConfig()
	cfg.LR = *lr
	cfg.Epochs = *epochs
	cfg.ContextLen = *ctx

	trainer := training.NewTrainer(model, embed, cfg)

	fmt.Println(":: starting training...")
	trainer.Train(allTokens, func(epoch, step int, loss float64) {
		fmt.Printf("   [epoch %d  step %d]  loss=%.4f\n", epoch, step, loss)
	})

	// Save
	if err := training.SaveModel(*savePath, model, embed); err != nil {
		fatalf("save model: %v", err)
	}
	if err := tok.Save(*tokPath); err != nil {
		fatalf("save tokenizer: %v", err)
	}
	fmt.Printf(":: saved model -> %s\n", *savePath)
	fmt.Printf(":: saved tokenizer -> %s\n", *tokPath)
}

// ─── generate ────────────────────────────────────────────────────────────────

func cmdGenerate(args []string) {
	fs := flag.NewFlagSet("generate", flag.ExitOnError)
	modelPath := fs.String("model", "model.json", "checkpoint path")
	tokPath := fs.String("tok", "tokenizer.json", "tokenizer path")
	prompt := fs.String("prompt", "", "input prompt")
	maxNew := fs.Int("max", 100, "max new tokens")
	temp := fs.Float64("temp", 0.8, "sampling temperature")
	topK := fs.Int("topk", 40, "top-k sampling")
	topP := fs.Float64("topp", 0.9, "nucleus sampling p")

	if err := fs.Parse(args); err != nil {
		fatalf("parse flags: %v", err)
	}

	model, embed, err := training.LoadModel(*modelPath)
	if err != nil {
		fatalf("load model: %v", err)
	}
	tok, err := tokenizer.Load(*tokPath)
	if err != nil {
		fatalf("load tokenizer: %v", err)
	}

	opts := generation.Options{
		MaxNew: *maxNew, Temp: *temp,
		TopK: *topK, TopP: *topP,
		ContextLen: 128,
	}

	p := *prompt
	if p == "" {
		fmt.Print("prompt> ")
		reader := bufio.NewReader(os.Stdin)
		line, err := reader.ReadString('\n')
		if err != nil {
			fatalf("read prompt: %v", err)
		}
		p = strings.TrimSpace(line)
	}

	fmt.Printf("\n--- generated ---\n")
	result := generation.Generate(model, embed, tok, p, opts)
	fmt.Println(result)
	fmt.Println("---")
}

// ─── serve ───────────────────────────────────────────────────────────────────

func cmdServe(args []string) {
	fs := flag.NewFlagSet("serve", flag.ExitOnError)
	modelPath := fs.String("model", "model.json", "checkpoint path")
	tokPath := fs.String("tok", "tokenizer.json", "tokenizer path")
	addr := fs.String("addr", "localhost:8080", "listen address")
	name := fs.String("name", "dynago-local", "model name for API")

	if err := fs.Parse(args); err != nil {
		fatalf("parse flags: %v", err)
	}

	model, embed, err := training.LoadModel(*modelPath)
	if err != nil {
		fatalf("load model: %v", err)
	}
	tok, err := tokenizer.Load(*tokPath)
	if err != nil {
		fatalf("load tokenizer: %v", err)
	}

	eng := server.NewEngine(model, embed, tok, *name)
	if err := eng.Serve(*addr); err != nil {
		fatalf("server: %v", err)
	}
}

// ─── chat ────────────────────────────────────────────────────────────────────

func cmdChat(args []string) {
	fs := flag.NewFlagSet("chat", flag.ExitOnError)
	modelPath := fs.String("model", "model.json", "checkpoint path")
	tokPath := fs.String("tok", "tokenizer.json", "tokenizer path")
	temp := fs.Float64("temp", 0.8, "sampling temperature")
	maxNew := fs.Int("max", 200, "max new tokens per turn")

	if err := fs.Parse(args); err != nil {
		fatalf("parse flags: %v", err)
	}

	model, embed, err := training.LoadModel(*modelPath)
	if err != nil {
		fatalf("load model: %v", err)
	}
	tok, err := tokenizer.Load(*tokPath)
	if err != nil {
		fatalf("load tokenizer: %v", err)
	}

	opts := generation.Options{
		MaxNew: *maxNew, Temp: *temp,
		TopK: 40, TopP: 0.9,
		ContextLen: 128,
	}

	fmt.Println(":: interactive chat  (type 'exit' to quit, 'clear' to reset)")
	fmt.Println(strings.Repeat("-", 50))

	reader := bufio.NewReader(os.Stdin)
	var history []string

	for {
		fmt.Print("\n> ")
		line, err := reader.ReadString('\n')
		if err != nil {
			fatalf("read input: %v", err)
		}
		line = strings.TrimSpace(line)

		if line == "exit" || line == "quit" {
			fmt.Println(":: goodbye")
			break
		}
		if line == "clear" {
			history = nil
			fmt.Println(":: context cleared")
			continue
		}
		if line == "" {
			continue
		}

		history = append(history, "[user] "+line)
		prompt := strings.Join(history, "\n") + "\n[assistant] "

		result := generation.Generate(model, embed, tok, prompt, opts)
		fmt.Printf("\n< %s\n", result)
		history = append(history, "[assistant] "+result)

		// Keep history from growing too large
		if len(history) > 20 {
			history = history[2:]
		}
	}
}

// ─── helpers ─────────────────────────────────────────────────────────────────

func printHelp() {
	fmt.Print(`
USAGE:
  dynago-ai <command> [flags]

COMMANDS:
  train     Train a model from a text file
  generate  Generate text from a trained model
  serve     Run OpenAI-compatible HTTP API + Web UI
  chat      Interactive terminal chat session

EXAMPLES:
  dynago-ai train  --data corpus.txt --epochs 10 --dim 256 --layers 6
  dynago-ai gen    --prompt "once upon a time" --temp 0.9
  dynago-ai serve  --addr 0.0.0.0:8080
  dynago-ai chat

  # Use as local LLM with any OpenAI client:
  openai.base_url = "http://localhost:8080/v1"
  openai.api_key  = "none"

Run 'dynago-ai <command> --help' for flag details.
`)
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "error: "+format+"\n", args...)
	os.Exit(1)
}