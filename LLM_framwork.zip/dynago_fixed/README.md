# dynago-ai

A pure-Go transformer engine — no external dependencies, no CGo, no Python.

Trains a causal language model from a text file and serves it via an
OpenAI-compatible REST API with a built-in web chat UI.

---

## Build

```bash
go build -o dynago-ai .
```

Requires Go 1.21+. Zero external dependencies.

---

## Commands

### `train` — train from a text corpus

```bash
./dynago-ai train \
  --data   corpus.txt \
  --save   model.json \
  --tok    tokenizer.json \
  --dim    256 \
  --layers 6 \
  --ctx    128 \
  --epochs 10 \
  --lr     3e-4
```

| Flag | Default | Description |
|------|---------|-------------|
| `--data` | (required) | Plain text training file |
| `--save` | `model.json` | Checkpoint output path |
| `--tok` | `tokenizer.json` | Tokenizer output path |
| `--dim` | `128` | Model embedding dimension |
| `--layers` | `4` | Number of transformer blocks |
| `--ctx` | `64` | Context window length |
| `--epochs` | `5` | Training epochs |
| `--lr` | `3e-4` | Learning rate (AdamW) |

---

### `generate` — sample from a trained model

```bash
./dynago-ai generate \
  --model model.json \
  --tok   tokenizer.json \
  --prompt "once upon a time" \
  --max   200 \
  --temp  0.8 \
  --topk  40 \
  --topp  0.9
```

Omit `--prompt` to be prompted interactively.

---

### `serve` — run the HTTP API + web UI

```bash
./dynago-ai serve \
  --model model.json \
  --tok   tokenizer.json \
  --addr  0.0.0.0:8080 \
  --name  my-model
```

Opens:
- `http://localhost:8080/` — Web chat UI
- `http://localhost:8080/v1/chat/completions` — OpenAI-compatible chat
- `http://localhost:8080/v1/completions` — OpenAI-compatible completions
- `http://localhost:8080/v1/models` — Model list
- `http://localhost:8080/health` — Health check

---

### `chat` — interactive terminal session

```bash
./dynago-ai chat \
  --model model.json \
  --tok   tokenizer.json \
  --temp  0.85
```

Type `clear` to reset context, `exit` to quit.

---

## Use as a local LLM (OpenAI-compatible)

Any client that supports a custom `base_url` will work:

**Python (openai SDK)**
```python
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8080/v1", api_key="none")
resp = client.chat.completions.create(
    model="my-model",
    messages=[{"role": "user", "content": "hello"}]
)
print(resp.choices[0].message.content)
```

**curl**
```bash
curl http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "my-model",
    "messages": [{"role": "user", "content": "hello world"}],
    "max_tokens": 100,
    "temperature": 0.8
  }'
```

**LangChain / LlamaIndex** — set `openai_api_base = "http://localhost:8080/v1"`

---

## Architecture

```
dynago-ai/
  core/
    tensor.go       Tensor struct with Data + Grad fields
    ops.go          MatMul, Add, GELU, Softmax, SoftmaxBackward
  nn/
    linear.go       y = xW + b  (forward + backward)
    layernorm.go    Row-wise normalization + gamma/beta (forward + backward)
    embedding.go    Lookup table [vocab, dim] → [seq, dim] (FIXED: no collapse)
  transformer/
    attention.go    Causal scaled dot-product, Wq/Wk/Wv/Wo projections
    block.go        Pre-LN block: LN→Attn→residual + LN→FF→residual
    transformer.go  Block stack + sinusoidal pos encoding + LM head
  tokenizer/
    tokenizer.go    Word-level tokenizer (vocab build vs encode separated)
  optimizer/
    adam.go         AdamW with moment tracking and bias correction
  loss/
    loss.go         Fused softmax + cross-entropy (forward + backward)
  training/
    trainer.go      Training loop: forward → loss → backward → clip → step
    checkpoint.go   JSON save/load for weights
  generation/
    generate.go     Autoregressive decode: greedy / top-k / nucleus sampling
  server/
    server.go       OpenAI-compatible REST API (completions + chat)
    ui.go           Embedded terminal-aesthetic web chat UI
  main.go           CLI: train | generate | serve | chat
```

## What was fixed from the prototype

| Issue | Fix |
|-------|-----|
| Embedding collapsed all tokens into one vector | `embedding.go` returns `[seq, dim]` matrix |
| Attention did `MatMul(Q, MatMul(K,V))` | Proper `softmax(QKᵀ/√d)V` with causal mask |
| No output projection | `transformer.go` has `LMHead` Linear + final LayerNorm |
| Adam was plain SGD | Full AdamW: β1/β2 moments, bias correction, weight decay |
| No backward pass anywhere | Per-layer backward methods accumulate into `.Grad` |
| Autograd was a single stub | Manual chain rule through entire graph |
| Activation was `x*x` | GELU with correct backward |
| No loss function | Fused softmax + cross-entropy |
| Markdown fences in Go files | Removed |
| Positional encoding missing | Sinusoidal PE added to transformer |
