package loss

import (
	"dynago-ai/core"
	"math"
)

// CrossEntropy computes mean cross-entropy loss and its gradient w.r.t. logits.
// logits: [seq, vocab]
// targets: [seq] int — the correct token index at each position
// Returns (scalar loss, dLogits [seq, vocab])
func CrossEntropy(logits *core.Tensor, targets []int) (float64, *core.Tensor) {
	seq := logits.R
	vocab := logits.C
	dLogits := core.Zeros(seq, vocab)
	totalLoss := 0.0

	for i := 0; i < seq; i++ {
		offset := i * vocab
		max := logits.Data[offset]
		for j := 1; j < vocab; j++ {
			if logits.Data[offset+j] > max {
				max = logits.Data[offset+j]
			}
		}

		sum := 0.0
		probs := make([]float64, vocab)
		for j := 0; j < vocab; j++ {
			e := math.Exp(logits.Data[offset+j] - max)
			probs[j] = e
			sum += e
		}
		for j := 0; j < vocab; j++ {
			probs[j] /= sum
		}

		tgt := targets[i]
		if tgt >= 0 && tgt < vocab {
			totalLoss -= math.Log(probs[tgt] + 1e-12)
		} else {
			// Handle invalid target indices gracefully or panic
			panic("Invalid target index")
		}

		// Compute gradient of cross-entropy w.r.t. logits:
		// dL/dlogit = p - 1[target]
		for j := 0; j < vocab; j++ {
			dLogits.Data[offset+j] = probs[j]
		}
		dLogits.Data[offset+tgt] -= 1.0
	}

	// Normalize by sequence length
	scale := 1.0 / float64(seq)
	totalLoss *= scale
	for i := range dLogits.Data {
		dLogits.Data[i] *= scale
	}

	return totalLoss, dLogits
}
