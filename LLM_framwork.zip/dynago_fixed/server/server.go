package server

import (
	"dynago-ai/generation"
	"dynago-ai/nn"
	"dynago-ai/tokenizer"
	"dynago-ai/transformer"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"
)

// Engine holds the loaded model for serving
type Engine struct {
	Model     *transformer.Transformer
	Embed     *nn.Embedding
	Tok       *tokenizer.Tokenizer
	ModelName string
	GenOpts   generation.Options
}

func NewEngine(model *transformer.Transformer, embed *nn.Embedding, tok *tokenizer.Tokenizer, name string) *Engine {
	return &Engine{
		Model:     model,
		Embed:     embed,
		Tok:       tok,
		ModelName: name,
		GenOpts:   generation.DefaultOptions(),
	}
}

// ─── OpenAI-compatible types ─────────────────────────────────────────────────

type CompletionRequest struct {
	Model       string  `json:"model"`
	Prompt      string  `json:"prompt"`
	MaxTokens   int     `json:"max_tokens"`
	Temperature float64 `json:"temperature"`
	TopP        float64 `json:"top_p"`
	TopK        int     `json:"top_k"`
}

type CompletionResponse struct {
	ID      string             `json:"id"`
	Object  string             `json:"object"`
	Created int64              `json:"created"`
	Model   string             `json:"model"`
	Choices []CompletionChoice `json:"choices"`
	Usage   UsageInfo          `json:"usage"`
}

type CompletionChoice struct {
	Text         string `json:"text"`
	Index        int    `json:"index"`
	FinishReason string `json:"finish_reason"`
}

type ChatRequest struct {
	Model       string        `json:"model"`
	Messages    []ChatMessage `json:"messages"`
	MaxTokens   int           `json:"max_tokens"`
	Temperature float64       `json:"temperature"`
	TopP        float64       `json:"top_p"`
}

type ChatMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatResponse struct {
	ID      string       `json:"id"`
	Object  string       `json:"object"`
	Created int64        `json:"created"`
	Model   string       `json:"model"`
	Choices []ChatChoice `json:"choices"`
	Usage   UsageInfo    `json:"usage"`
}

type ChatChoice struct {
	Index        int         `json:"index"`
	Message      ChatMessage `json:"message"`
	FinishReason string      `json:"finish_reason"`
}

type UsageInfo struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

type ModelInfo struct {
	ID      string `json:"id"`
	Object  string `json:"object"`
	Created int64  `json:"created"`
	OwnedBy string `json:"owned_by"`
}

type ModelList struct {
	Object string      `json:"object"`
	Data   []ModelInfo `json:"data"`
}

// ─── Server ───────────────────────────────────────────────────────────────────

func (e *Engine) Serve(addr string) error {
	mux := http.NewServeMux()

	// Web UI
	mux.HandleFunc("/", e.handleUI)

	// OpenAI-compatible API
	mux.HandleFunc("/v1/models", cors(e.handleModels))
	mux.HandleFunc("/v1/completions", cors(e.handleCompletions))
	mux.HandleFunc("/v1/chat/completions", cors(e.handleChat))

	// Health check
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status":"ok","model":"%s"}`, e.ModelName)
	})

	log.Printf("dynago-ai serving on http://%s", addr)
	log.Printf("  Web UI:          http://%s/", addr)
	log.Printf("  OpenAI API:      http://%s/v1/", addr)
	log.Printf("  Completions:     http://%s/v1/completions", addr)
	log.Printf("  Chat:            http://%s/v1/chat/completions", addr)
	log.Printf("  Models:          http://%s/v1/models", addr)
	return http.ListenAndServe(addr, mux)
}

func (e *Engine) handleModels(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	list := ModelList{
		Object: "list",
		Data: []ModelInfo{
			{
				ID:      e.ModelName,
				Object:  "model",
				Created: time.Now().Unix(),
				OwnedBy: "dynago-ai",
			},
		},
	}
	if err := json.NewEncoder(w).Encode(list); err != nil {
		log.Printf("Error encoding models response: %v", err)
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}
}

func (e *Engine) handleCompletions(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req CompletionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	opts := e.GenOpts
	if req.MaxTokens > 0 {
		opts.MaxNew = req.MaxTokens
	}
	if req.Temperature > 0 {
		opts.Temp = req.Temperature
	}
	if req.TopP > 0 {
		opts.TopP = req.TopP
	}
	if req.TopK > 0 {
		opts.TopK = req.TopK
	}

	promptTokens := len(e.Tok.Encode(req.Prompt))
	result := generation.Generate(e.Model, e.Embed, e.Tok, req.Prompt, opts)
	
	// Fix: Ensure we count only the new tokens (not including prompt)
	completionTokens := len(e.Tok.Encode(result)) - promptTokens
	if completionTokens < 0 {
		completionTokens = 0
	}

	resp := CompletionResponse{
		ID:      fmt.Sprintf("cmpl-%d", time.Now().UnixNano()),
		Object:  "text_completion",
		Created: time.Now().Unix(),
		Model:   e.ModelName,
		Choices: []CompletionChoice{{
			Text:         result,
			Index:        0,
			FinishReason: "stop",
		}},
		Usage: UsageInfo{
			PromptTokens:     promptTokens,
			CompletionTokens: completionTokens,
			TotalTokens:      promptTokens + completionTokens,
		},
	}

	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(resp); err != nil {
		log.Printf("Error encoding completion response: %v", err)
		return
	}
}

func (e *Engine) handleChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req ChatRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Flatten messages into a prompt
	var sb strings.Builder
	for _, msg := range req.Messages {
		switch msg.Role {
		case "system":
			sb.WriteString("[system] " + msg.Content + "\n")
		case "user":
			sb.WriteString("[user] " + msg.Content + "\n")
		case "assistant":
			sb.WriteString("[assistant] " + msg.Content + "\n")
		}
	}
	sb.WriteString("[assistant] ")
	prompt := sb.String()

	opts := e.GenOpts
	if req.MaxTokens > 0 {
		opts.MaxNew = req.MaxTokens
	}
	if req.Temperature > 0 {
		opts.Temp = req.Temperature
	}
	if req.TopP > 0 {
		opts.TopP = req.TopP
	}

	promptTokens := len(e.Tok.Encode(prompt))
	result := generation.Generate(e.Model, e.Embed, e.Tok, prompt, opts)
	
	// Fix: Count only the completion tokens (not including prompt)
	completionTokens := len(e.Tok.Encode(result)) - promptTokens
	if completionTokens < 0 {
		completionTokens = 0
	}

	resp := ChatResponse{
		ID:      fmt.Sprintf("chatcmpl-%d", time.Now().UnixNano()),
		Object:  "chat.completion",
		Created: time.Now().Unix(),
		Model:   e.ModelName,
		Choices: []ChatChoice{{
			Index: 0,
			Message: ChatMessage{
				Role:    "assistant",
				Content: result,
			},
			FinishReason: "stop",
		}},
		Usage: UsageInfo{
			PromptTokens:     promptTokens,
			CompletionTokens: completionTokens,
			TotalTokens:      promptTokens + completionTokens,
		},
	}

	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(resp); err != nil {
		log.Printf("Error encoding chat response: %v", err)
		return
	}
}

func (e *Engine) handleUI(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprint(w, webUI(e.ModelName))
}

func cors(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		h(w, r)
	}
}
