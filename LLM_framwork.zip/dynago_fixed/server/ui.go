
package server

import "fmt"

func webUI(modelName string) string {
	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>dynago-ai // %s</title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;700&display=swap" rel="stylesheet">
<style>
:root {
  --bg:#050a05; --surface:#0a140a; --border:#1a3d1a;
  --green:#00ff41; --green-dim:#00c832; --green-faint:#003a10;
  --amber:#ffb800; --red:#ff2d55;
  --text:#c8ffc8; --text-dim:#4a8a4a;
  --glow:0 0 8px #00ff4160,0 0 20px #00ff4120;
  --font:'JetBrains Mono',monospace;
}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:var(--font);height:100vh;display:flex;flex-direction:column;overflow:hidden}
body::before{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,0,0,.08) 2px,rgba(0,0,0,.08) 4px);pointer-events:none;z-index:9999}
body::after{content:'';position:fixed;inset:0;background:radial-gradient(ellipse at center,transparent 60%%,rgba(0,0,0,.6) 100%%);pointer-events:none;z-index:9998}
header{padding:12px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:16px;background:var(--surface);flex-shrink:0}
.logo{font-size:18px;font-weight:700;color:var(--green);text-shadow:var(--glow);letter-spacing:2px}
.logo span{color:var(--text-dim);font-weight:300}
.badge{font-size:11px;background:var(--green-faint);border:1px solid var(--border);color:var(--green-dim);padding:3px 10px;border-radius:2px;letter-spacing:1px}
.status{margin-left:auto;font-size:11px;color:var(--text-dim);display:flex;align-items:center;gap:8px}
.dot{width:7px;height:7px;border-radius:50%%;background:var(--green);box-shadow:0 0 6px var(--green);animation:pulse 2s infinite}
@keyframes pulse{0%%,100%%{opacity:1}50%%{opacity:.3}}
.layout{display:flex;flex:1;overflow:hidden}
.sidebar{width:230px;border-right:1px solid var(--border);padding:16px;display:flex;flex-direction:column;gap:18px;background:var(--surface);flex-shrink:0;overflow-y:auto}
.sec-label{font-size:10px;letter-spacing:2px;color:var(--text-dim);text-transform:uppercase;margin-bottom:4px}
.pr{display:flex;justify-content:space-between;align-items:center;font-size:12px;margin-bottom:3px}
.pn{color:var(--text-dim)}
.pv{color:var(--green);text-shadow:0 0 4px #00ff4140}
input[type=range]{width:100%%;accent-color:var(--green);cursor:pointer}
.api-box{background:#001a0a;border:1px solid var(--border);border-radius:2px;padding:10px 12px;font-size:11px;color:var(--text-dim);line-height:2}
.api-box .ep{color:var(--amber);font-size:10px}
.api-box code{color:var(--green-dim)}
.chat-area{flex:1;display:flex;flex-direction:column;overflow:hidden}
#msgs{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:16px;scroll-behavior:smooth}
#msgs::-webkit-scrollbar{width:4px}
#msgs::-webkit-scrollbar-thumb{background:var(--border);border-radius:2px}
.msg{display:flex;flex-direction:column;gap:4px;max-width:80%%;animation:fs .2s ease-out}
@keyframes fs{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.msg.user{align-self:flex-end}
.msg.bot{align-self:flex-start}
.mr{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--text-dim);padding:0 4px}
.msg.user .mr{text-align:right;color:var(--amber);opacity:.7}
.msg.bot .mr{color:var(--green-dim)}
.mb{padding:10px 14px;border-radius:2px;font-size:13px;line-height:1.7;white-space:pre-wrap;word-break:break-word}
.msg.user .mb{background:#1a1200;border:1px solid #3d2a00;color:#ffd080}
.msg.bot .mb{background:var(--green-faint);border:1px solid var(--border);color:var(--text);border-left:3px solid var(--green)}
.thinking .mb::after{content:'█';animation:blink .8s step-end infinite;color:var(--green)}
@keyframes blink{50%%{opacity:0}}
.sys{text-align:center;font-size:11px;color:var(--text-dim);padding:4px 0;letter-spacing:1px;opacity:.7}
.input-area{padding:14px 20px;border-top:1px solid var(--border);background:var(--surface);display:flex;gap:10px;align-items:flex-end;flex-shrink:0}
#prompt{flex:1;background:var(--bg);border:1px solid var(--border);color:var(--text);font-family:var(--font);font-size:13px;padding:10px 14px;border-radius:2px;resize:none;outline:none;min-height:42px;max-height:160px;line-height:1.5;transition:border-color .15s}
#prompt:focus{border-color:var(--green);box-shadow:0 0 0 1px #00ff4130}
#prompt::placeholder{color:var(--text-dim)}
.btn{font-family:var(--font);font-size:12px;font-weight:700;letter-spacing:2px;padding:10px 16px;cursor:pointer;border-radius:2px;transition:all .15s;flex-shrink:0;align-self:flex-end;text-transform:uppercase}
#send{background:var(--green-faint);border:1px solid var(--green);color:var(--green)}
#send:hover:not(:disabled){background:var(--green);color:var(--bg);box-shadow:var(--glow)}
#send:disabled{opacity:.3;cursor:not-allowed}
#clr{background:transparent;border:1px solid var(--border);color:var(--text-dim)}
#clr:hover{border-color:var(--red);color:var(--red)}
@media(max-width:600px){.sidebar{display:none}}
</style>
</head>
<body>
<header>
  <div class="logo">dynago<span>-</span>ai</div>
  <div class="badge">%s</div>
  <div class="status"><div class="dot"></div><span>ONLINE</span></div>
</header>
<div class="layout">
  <aside class="sidebar">
    <div>
      <div class="sec-label">// sampling</div>
      <div class="pr"><span class="pn">temperature</span><span class="pv" id="tv">0.80</span></div>
      <input type="range" id="temp" min="0.1" max="2.0" step="0.05" value="0.8" oninput="document.getElementById('tv').textContent=parseFloat(this.value).toFixed(2)">
      <div class="pr" style="margin-top:8px"><span class="pn">top_p</span><span class="pv" id="ppv">0.90</span></div>
      <input type="range" id="topp" min="0.1" max="1.0" step="0.05" value="0.9" oninput="document.getElementById('ppv').textContent=parseFloat(this.value).toFixed(2)">
      <div class="pr" style="margin-top:8px"><span class="pn">top_k</span><span class="pv" id="kv">40</span></div>
      <input type="range" id="topk" min="1" max="100" step="1" value="40" oninput="document.getElementById('kv').textContent=this.value">
      <div class="pr" style="margin-top:8px"><span class="pn">max_tokens</span><span class="pv" id="mv">100</span></div>
      <input type="range" id="maxt" min="10" max="500" step="10" value="100" oninput="document.getElementById('mv').textContent=this.value">
    </div>
    <div>
      <div class="sec-label">// api</div>
      <div class="api-box">
        <div class="ep">POST /v1/completions</div>
        <div class="ep">POST /v1/chat/completions</div>
        <div class="ep">GET  /v1/models</div>
        <div style="margin-top:6px;font-size:10px">
          OpenAI-compatible<br>
          base_url: <code id="baseurl"></code>
        </div>
      </div>
    </div>
  </aside>
  <div class="chat-area">
    <div id="msgs"><div class="sys">// session initialized — %s</div></div>
    <div class="input-area">
      <textarea id="prompt" placeholder="Enter prompt..." rows="1"
        onkeydown="handleKey(event)" oninput="resize(this)"></textarea>
      <button class="btn" id="clr" onclick="clearChat()">CLR</button>
      <button class="btn" id="send" onclick="send()">SEND ↵</button>
    </div>
  </div>
</div>
<script>
const MODEL='%s';
document.getElementById('baseurl').textContent=location.origin+'/v1';
const msgs=document.getElementById('msgs');
let hist=[];
function resize(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,160)+'px'}
function handleKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}
function addMsg(role,text,thinking){
  const d=document.createElement('div');d.className='msg '+(role==='user'?'user':'bot')+(thinking?' thinking':'');
  const r=document.createElement('div');r.className='mr';r.textContent=role==='user'?'> you':'< model';
  const b=document.createElement('div');b.className='mb';b.textContent=text||'';
  d.append(r,b);msgs.append(d);msgs.scrollTop=msgs.scrollHeight;return b;
}
async function send(){
  const inp=document.getElementById('prompt');
  const txt=inp.value.trim();if(!txt)return;
  const btn=document.getElementById('send');btn.disabled=true;
  inp.value='';inp.style.height='auto';
  addMsg('user',txt);hist.push({role:'user',content:txt});
  const bb=addMsg('bot','',true);
  try{
    const r=await fetch('/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({model:MODEL,messages:hist,
        max_tokens:+document.getElementById('maxt').value,
        temperature:+document.getElementById('temp').value,
        top_p:+document.getElementById('topp').value,
        top_k:+document.getElementById('topk').value})});
    const d=await r.json();
    const rep=d.choices?.[0]?.message?.content||'[no response]';
    bb.parentElement.classList.remove('thinking');bb.textContent=rep;
    hist.push({role:'assistant',content:rep});
  }catch(e){
    bb.parentElement.classList.remove('thinking');bb.style.color='var(--red)';bb.textContent='Error: '+e.message;
  }
  btn.disabled=false;inp.focus();msgs.scrollTop=msgs.scrollHeight;
}
function clearChat(){hist=[];msgs.innerHTML='<div class="sys">// session cleared</div>';}
</script>
</body>
</html>`, modelName, modelName, modelName, modelName)
}
